How to Create a Responsive Image Slider in jQuery and CSS3 
"How to Create a Responsive Image Slider in jQuery and CSS3" was specially made for DesignModo by our friend Valeriu Timbuc. 

"How to Create a Responsive Image Slider in jQuery and CSS3" is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/). 

You are allowed to use these freebie anywhere you want, however we�ll highly appreciate if you will link to our website when you share them - http://designmodo.com

Thanks for supporting our website and enjoy!

Links:
http://codecanyon.net/user/downv?ref=downv
http://designmodo.com/responsive-slider
http://designmodo.com/impressionist
http://vladimirkudinov.com
http://rockablethemes.com